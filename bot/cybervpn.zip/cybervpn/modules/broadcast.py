from cybervpn import *
import subprocess
import json
import re
import base64
import datetime as DT
import requests
import time

@bot.on(events.NewMessage(pattern=r"/broadcast"))
@bot.on(events.CallbackQuery(data=b'broadcast'))
async def broadcast(event):
    if event.is_private:
        return

    level = get_level_from_db(str(event.sender_id))
    if level != 'admin':
        await event.respond("Anda tidak memiliki izin untuk melakukan broadcast.", buttons=[
            [Button.inline("🔙 Kembali", "menu")]
        ])
        return

    await event.respond("Kirimkan pesan/foto/video yang ingin Anda broadcast.")
    response = await event.get_response()

    # Cek jika pesan kosong
    if not response.text and not response.media:
        await event.respond("Pesan tidak boleh kosong. Silakan coba lagi.", buttons=[
            [Button.inline("🔄 Ulangi", "broadcast")],
            [Button.inline("❌ Batal", "menu")]
        ])
        return

    success = 0
    failed = 0

    async for user in bot.iter_dialogs():
        if user.is_user and user.id != event.sender_id:  # Hindari mengirim ke diri sendiri
            try:
                if response.photo:
                    await bot.send_file(user.id, 
                        file=response.photo,
                        caption=response.text if response.text else None)
                
                elif response.video:
                    await bot.send_file(user.id, 
                        file=response.video,
                        caption=response.text if response.text else None)
                
                elif response.document:
                    await bot.send_file(user.id, 
                        file=response.document,
                        caption=response.text if response.text else None)
                
                elif response.audio:
                    await bot.send_file(user.id, 
                        file=response.audio,
                        caption=response.text if response.text else None)
                
                else:
                    await bot.send_message(user.id, response.text)
                
                success += 1
                
            except Exception as e:
                print(f"Gagal mengirim ke {user.id}: {e}")
                failed += 1
                continue

    await event.respond(f"Broadcast selesai!\nBerhasil: {success}\nGagal: {failed}", buttons=[
        [Button.inline("🔙 Kembali", "menu")]
    ])