#!/bin/bash
function send_log(){
    # Bot pertama
    CHATID=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 3)
    KEY=$(grep -E "^#bot# " "/etc/bot/.bot.db" | cut -d ' ' -f 2)
    TEXT="
◇━━━━━━━━━━━━━━━━━◇
    🔗GENERATE LINK BACKUP🔗
◇━━━━━━━━━━━━━━━━━◇
LINK BACKUP : $fix
◇━━━━━━━━━━━━━━━━━◇
"
    # Kirim ke bot pertama
    URL="https://api.telegram.org/bot$KEY/sendMessage"
    curl -s -X POST $URL --data-urlencode "chat_id=$CHATID" --data-urlencode "text=$TEXT" >/dev/null
}
clear
echo -e ""
echo -e "\033[96;1m============================\033[0m"
echo -e "\033[93;1m  INPUT IP DAN TANGGAL"
echo -e "\033[96;1m============================\033[0m"
echo -e "\033[91;1m contoh IP-YYYY-MM-DD :\033[0m123.123.123.123-2050-01-31\033[93\033[0m"
read -p "IP-YYYY-MM-DD :  " iptanggal
echo -e ""
url=$(rclone link del:backup/WT-${iptanggal}.zip) 
id=(`echo $url | grep '^https' | cut -d'=' -f2`)
link="https://drive.google.com/u/4/uc?id=${id}&export=download"
fix=$(jq -nr --arg msg "$link" '$msg')
clear
send_log
echo -e "
==================================
SUCCESSFULL GENERATE LINK BACKUP
==================================
LINK BACKUP : $link
==================================
"
echo "Silahkan copy Link dan restore di VPS baru"
echo ""